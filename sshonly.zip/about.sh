#!/bin/bash

clear
echo -e "=================================================" | lolcat
echo -e "#         Premium Auto Script By Gugun          #"
echo -e "#-----------------------------------------------#" | lolcat
echo -e "# For Debian 9 & Debian 10 64 bit               #"
echo -e "# For Ubuntu 18.04 & Ubuntu 20.04 64 bit        #"
echo -e "# For VPS with KVM and VMWare virtualization    #"
echo -e "# Mod By Gugun09                                #"
echo -e "#-----------------------------------------------#" | lolcat
echo -e "# Thanks To                                     #"
echo -e "#-----------------------------------------------#" | lolcat
echo -e "# Allah                                         #"
echo -e "#-----------------------------------------------#" | lolcat
echo -e "=================================================" | lolcat
